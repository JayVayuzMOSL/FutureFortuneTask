class AppRouteNames {
  static const String loginRoute = '/';
  static const String homeRoute = '/home';
  static const String signupRoute = '/signup';
  static const String addItemRoute = '/addItem';
  static const String editItemRoute = '/editItem';
}

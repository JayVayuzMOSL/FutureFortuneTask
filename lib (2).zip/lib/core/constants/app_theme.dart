//
// import 'package:flutter/material.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import '../shared/app_colors.dart';
// import 'app_colors.dart';
//
// class AppTheme {
//   static ThemeData lightTheme = ThemeData(
//     brightness: Brightness.light,
//     primaryColor: AppColors.primaryLight,
//     scaffoldBackgroundColor: AppColors.backgroundLight,
//     colorScheme: AppColors.lightColorScheme,
//     textTheme: GoogleFonts.publicSansTextTheme().copyWith(
//       titleLarge: GoogleFonts.publicSans(fontSize: 18.sp, fontWeight: FontWeight.w500),
//       titleMedium: GoogleFonts.publicSans(fontSize: 16.sp, fontWeight: FontWeight.w500),
//       bodyLarge: GoogleFonts.publicSans(fontSize: 16.sp, fontWeight: FontWeight.w400),
//     ),
//   );
// }
